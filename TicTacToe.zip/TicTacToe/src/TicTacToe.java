/**
 * TicTacToe class implements the interface
 * @author relkharboutly
 * @editor Victoria Gorski
 * @date 1/5/2017
 */

// Start of class, implements ITicTacToe interface
public class TicTacToe implements ITicTacToe {
		 
	// Instance variables
	private static final int ROWS = 3, COLS = 3;
	private int[][] board = new int[ROWS][COLS];
	public int playerSymbol = CROSS;
	  
	// Constructor
	public TicTacToe(){
		
	}
	
	// Methods
	// Clears the board and creates a new game
	@Override
	public void clearBoard() {
		board = new int[ROWS][COLS];
	}
	
	// Matches the integer the user typed in to a location on the board
	public void findLocation(int location) {
		switch (location) {
		case 0:
			board[0][0] = CROSS;
			break;
		case 1:
			board[0][1] = CROSS;
			break;
		case 2:
			board[0][2] = CROSS;
			break;
		case 3:
			board[1][0] = CROSS;
			break;
		case 4:
			board[1][1] = CROSS;
			break;
		case 5: 
			board[1][2] = CROSS;
			break;
		case 6:
			board[2][0] = CROSS;
			break;
		case 7:
			board[2][1] = CROSS;
			break;
		case 8:
			board[2][2] = CROSS;
			break;
		default:	
		}

	}

	// Sets the move in the designated location
	@Override
	public void setMove(int player, int location) {
		
		// If the location does not exist, print out this message
		if(location < 0 || location > 8 || location == EMPTY) {
			System.out.println("That space doesn't exist!");
		// Else look for the location
		} else {
			findLocation(location);
		}
	}

	// Controls where the computer makes its move
	@Override
	public int getComputerMove() {
		// Center if it is open
		if (board[1][1] == EMPTY) 
		    return board[1][1] = NOUGHT; 
		
		// Each corner if it is open
		if (board[0][0] == EMPTY) 
		    return board[0][0] = NOUGHT; 
		if (board[0][2] == EMPTY) 
		    return board[0][2] = NOUGHT; 
		if (board[2][0] == EMPTY) 
		    return board[2][0] = NOUGHT; 
		if (board[2][2] == EMPTY) 
		    return board[2][2] = NOUGHT; 

		// Each edge if it is open 
		if (board[0][1] == EMPTY) 
		    return board[0][1] = NOUGHT; 
		if (board[1][0] == EMPTY)
		    return board[1][0] = NOUGHT; 
		if (board[1][2] == EMPTY) 
		    return board[1][2] = NOUGHT; 
		if (board[2][1] == EMPTY) 
		    return board[2][1] = NOUGHT; 
		return 0;

	}

	// Checks if there is a winner
	@Override
	public int checkForWinner() {
		
		int winner = PLAYING;
	// If three of the same symbol is placed in a certain pattern and the space is not empty, display the winner
		// Checks spots 0, 1, and 2
		if (board[0][0] == board[0][1] && board[0][1] == board[0][2] && board[0][2] == board[0][0] && board[0][0] != EMPTY) {
			if(board[0][0] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		}
		
		// Checks spots 4,5, and 6
		else if (board[1][0] == board[1][1] && board[1][1] == board[1][2] && board[1][2] == board[1][0] && board[1][0] != EMPTY) {
			if (board[1][0] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;}
		}
		
		// Checks spots 7, 8, and 9
		else if (board[2][0] == board[2][1] && board[2][1] == board[2][2] && board[2][2] == board[2][0] && board[2][0] != EMPTY) {
			if (board[2][0] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		} 
		
		// Checks spots 1, 4, and 7
		else if (board[0][0] == board[1][0] && board[1][0] == board[2][0] && board[2][0] == board[0][0] && board[0][0] != EMPTY) {
			if (board[0][0] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		}
		
		// Checks spots 2, 5, and 8
		else if (board[0][1] == board[1][1] && board[1][1] == board[2][1] && board[2][1] == board[0][1] && board[0][1] != EMPTY) {
			if (board[0][1] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		}
		
		// Checks spots 3, 6, and 9 
		else if (board[0][2] == board[1][2] && board[1][2] == board[2][2] && board[2][2] == board[0][2] && board[0][2] != EMPTY) {
			if (board[0][2] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		}
		
		// Checks spots 1, 5, and 9
		else if (board[0][0] == board[1][2] && board[1][2] == board[2][2] && board[2][2] == board[0][0] && board[0][0] != EMPTY) {
			if (board[0][0] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		}

		// Checks spots 3, 5, and 7
		if (board[0][2] == board[1][2] && board[1][2] == board[2][0] && board[2][0] == board[0][2] && board[0][2] != EMPTY) {
			if (board[0][2] == CROSS) {
				return winner = CROSS_WON;
			} else {
				return winner = NOUGHT_WON;
			}
		}
		
		// If the board is filled up and there is no winner, say it's a tie
		else if (board[0][0] != EMPTY && board[0][1] != EMPTY && board[0][2] != EMPTY && board[1][0] != EMPTY && board[1][1] != EMPTY && board[1][2] != EMPTY && board[2][0] != EMPTY && board[2][1] != EMPTY && board[2][2] != EMPTY) {
			return winner = TIE; }
		return winner; }
		
	    
	// Prints the game board
	public  void printBoard() {
	for (int row = 0; row < ROWS; ++row) {
	for (int col = 0; col < COLS; ++col) {
		
	// Prints each cell
	printCell(board[row][col]); 
	if (col != COLS - 1) {
	// Print out each column
	System.out.print("|");   
		}
	}
	
	// Print out each row
	System.out.println();
	if (row != ROWS - 1) {
	System.out.println("-----------");
		}
	}
	System.out.println();
	   }
	 
	// Prints a cell with either a 'X', 'O', or a space
	public void printCell(int content) {
		switch (content) {
			case EMPTY:  System.out.print("   "); break;
			case NOUGHT: System.out.print(" O "); break;
			case CROSS:  System.out.print(" X "); break;
			}
		}
}
