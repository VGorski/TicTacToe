/**
 * Tic-Tac-Toe: Two-player console, non-graphics
 * @author relkharboutly
 * @editor Victoria Gorski
 * @date 1/5/2017
 */

// Imports
import java.util.Scanner;

// Start of class
public class TTTConsole  {
    
	// Instance variables
	public static Scanner in = new Scanner(System.in);
	public static TicTacToe TTTboard = new TicTacToe();
	public static void main(String[] args) {
	int COMPUTER_PLAYER = TTTboard.getComputerMove();
	int currentState = TicTacToe.PLAYING;
	
	// Prompt to start the game 
	System.out.println("Would you like to be player 1 or 2?");
	int HUMAN_PLAYER = in.nextInt();

	// Start of game loop 
	do {
	// Print board
	// Instructions for player
	System.out.println("Type a move between 0 - 8!");
	// Player's move
	int location = in.nextInt();
	TTTboard.setMove(HUMAN_PLAYER, location);
	// Refresh the board 
	TTTboard.printBoard();
	currentState = TTTboard.checkForWinner();
	
	// Computer's move
	TTTboard.getComputerMove();
	TTTboard.setMove(COMPUTER_PLAYER, location);
	currentState = TTTboard.checkForWinner();

	// If the player won, print this
	if (currentState == ITicTacToe.CROSS_WON) {
		System.out.println("'X' won! Bye!");
	// If computer won, print this
	} else if (currentState == ITicTacToe.NOUGHT_WON) {
		System.out.println("'O' won! Bye!");
	// If it is a tie, print this
	} else if (currentState == ITicTacToe.TIE) {
		System.out.println("It's a TIE! Bye!");
	}
         
	// If the game is not over, keep running the loop
	} while (currentState == ITicTacToe.PLAYING);
	}
}